export class Doctor {
   _id:string;
   firstname : string;
   lastname : string;
   speciality : string;
   gender : string ;
   image:string;
   degree : string;
   college : string;
   eoc : string;
   eoy : string ; 
   clinicname: string;
   cliniccity: string;
   clinicaddress: string;

}

// export class Demo{
//    firstname : String;
//    lastname : String;
//    speciality : String;
//    gender : String ;
// }

// export class Education
// {
//    degree : String;
//    college : String;
//    eoc : String;
//    eoy : String ;
// }